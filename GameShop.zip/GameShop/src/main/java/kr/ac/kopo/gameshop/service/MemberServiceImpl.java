package kr.ac.kopo.gameshop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.gameshop.dao.MemberDao;
import kr.ac.kopo.gameshop.model.Member;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	MemberDao dao;
	
	@Override
	public boolean login(Member member) {
		// TODO Auto-generated method stub
		Member item=dao.login(member);
		if(item != null) { 
			
			member.setName(item.getName());
			member.setPasswd(null);
			member.setRegDate(item.getRegDate());
			return true;
		}
		else {
			return false;
		}
		
	}

}
