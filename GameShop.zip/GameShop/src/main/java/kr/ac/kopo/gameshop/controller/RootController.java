package kr.ac.kopo.gameshop.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.kopo.gameshop.model.Member;
import kr.ac.kopo.gameshop.service.MemberService;


@Controller
public class RootController {
	
	@Autowired
	MemberService service;
	
	@RequestMapping("/") //처리할 주소
	public String index() {
		return"index";//index.jsp파일을 사용자에게 보여주겠다.
	}
	@RequestMapping("/login")
	public String login() {
		return "login";
	}
	@PostMapping("/login")
	public String login(Member member, HttpSession session) {
		if (service.login(member)) {
			session.setAttribute("member", member);//멤버의 정보를 세션에 넣음
			
			return "redirect:.";
		}
		else {
			return "redirect:login";
		}
		
	}
	
	@RequestMapping
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:.";
	}
	
}
